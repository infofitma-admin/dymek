(function(){
"use strict";
var d=document, root=d.documentElement;
root.classList.add("js");
function $(s,c){return (c||d).querySelector(s)}
function $$(s,c){return Array.prototype.slice.call((c||d).querySelectorAll(s))}
function store(k,v){try{if(v===undefined)return localStorage.getItem(k);localStorage.setItem(k,v)}catch(e){return null}}
var HOST=location.hostname||"";
var LIVE=/(^|\.)dymek\.com$|netlify\.app$/.test(HOST);          // real deployment: forms + embeds on
var CAN_EMBED=/^https?:$/.test(location.protocol)&&!/claude|anthropic|claudeusercontent/.test(HOST);

function toast(msg){var t=d.createElement("div");t.className="toast";t.setAttribute("role","status");t.textContent=msg;d.body.appendChild(t);setTimeout(function(){t.remove()},2400)}
function copy(text,btn){
  function done(){toast("Copied: "+text);if(btn){var o=btn.textContent;btn.textContent="Copied";setTimeout(function(){btn.textContent=o},1600)}}
  try{navigator.clipboard.writeText(text).then(done,function(){fallback()})}catch(e){fallback()}
  function fallback(){var r=d.createRange(),el=btn&&btn.previousElementSibling;if(el){r.selectNodeContents(el);var s=getSelection();s.removeAllRanges();s.addRange(r);toast("Selected. Press Ctrl+C to copy")}}
}
$$("[data-copy]").forEach(function(b){b.addEventListener("click",function(e){e.preventDefault();copy(b.getAttribute("data-copy"),b)})});

/* theme toggle */
var saved=store("dymek-theme"); if(saved==="dark"||saved==="light") root.setAttribute("data-theme",saved);
$$("[data-theme-toggle]").forEach(function(b){b.addEventListener("click",function(){
  var cur=root.getAttribute("data-theme")||(matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light");
  var nx=cur==="dark"?"light":"dark"; root.setAttribute("data-theme",nx); store("dymek-theme",nx);
  b.setAttribute("aria-label","Switch to "+(nx==="dark"?"light":"dark")+" theme");
})});

/* images: hide photo if it fails so the pattern shows */
$$("img.photo").forEach(function(img){
  function fail(){var f=img.closest(".frame,.video");if(f)f.classList.add("noimg");img.remove()}
  if(img.complete&&img.naturalWidth===0&&img.getAttribute("src"))fail(); else img.addEventListener("error",fail);
});

/* header: scrolled state + ruler gauge */
var head=$(".site-head"), ruler=$(".ruler");
function onScroll(){
  var y=scrollY, h=d.documentElement.scrollHeight-innerHeight;
  if(head) head.classList.toggle("scrolled",y>8);
  if(ruler){var p=h>0?Math.min(100,y/h*100):0; ruler.style.setProperty("--p",p.toFixed(2)+"%"); var b=$("b",ruler); if(b) b.textContent=Math.round(p)+"%"}
  var tt=$(".to-top"); if(tt) tt.hidden=y<600;
}
addEventListener("scroll",onScroll,{passive:true}); onScroll();

/* dropdowns / mega menu */
var openBtn=null;
function closeMenus(except){$$(".nav-a[aria-expanded]").forEach(function(b){if(b!==except){b.setAttribute("aria-expanded","false");var p=d.getElementById(b.getAttribute("aria-controls"));if(p)p.hidden=true}});if(!except)openBtn=null}
$$(".nav-a[aria-controls]").forEach(function(b){
  var panel=d.getElementById(b.getAttribute("aria-controls")), li=b.parentElement, t;
  function open(){closeMenus(b);b.setAttribute("aria-expanded","true");panel.hidden=false;openBtn=b}
  function close(){b.setAttribute("aria-expanded","false");panel.hidden=true}
  b.addEventListener("click",function(e){e.preventDefault();b.getAttribute("aria-expanded")==="true"?close():open()});
  li.addEventListener("mouseenter",function(){if(matchMedia("(hover:hover)").matches){clearTimeout(t);open()}});
  li.addEventListener("mouseleave",function(){if(matchMedia("(hover:hover)").matches){t=setTimeout(close,180)}});
  li.addEventListener("focusout",function(e){if(!li.contains(e.relatedTarget))close()});
});
d.addEventListener("click",function(e){if(!e.target.closest(".nav"))closeMenus()});
d.addEventListener("keydown",function(e){if(e.key==="Escape"){if(openBtn){var b=openBtn;closeMenus();b.focus()}closeSearch();closeDrawer();closeHelper()}});

/* mobile drawer */
var drawer=$("#drawer");
function closeDrawer(){if(drawer&&!drawer.hidden){drawer.hidden=true;d.body.style.overflow="";var mb=$(".menu-btn");if(mb){mb.setAttribute("aria-expanded","false");mb.focus()}}}
$$(".menu-btn").forEach(function(b){b.addEventListener("click",function(){drawer.hidden=false;b.setAttribute("aria-expanded","true");d.body.style.overflow="hidden";var f=$("button,a",drawer);if(f)f.focus()})});
$$("[data-close-drawer]").forEach(function(b){b.addEventListener("click",closeDrawer)});

/* site search */
var ov=$("#search"), sin=$("#search-input"), list=$("#search-results"), sel=-1;
function esc(s){return s.replace(/[&<>"]/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]})}
function hl(text,q){if(!q)return esc(text);var re=new RegExp("("+q.split(/\s+/).filter(Boolean).map(function(w){return w.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}).join("|")+")","ig");return esc(text).replace(re,"<mark>$1</mark>")}
function search(q){
  var idx=window.DYMEK_INDEX||[]; q=(q||"").trim().toLowerCase();
  var words=q.split(/\s+/).filter(Boolean), out=[];
  if(!words.length){out=idx.filter(function(p){return p.f}).slice(0,8)}
  else idx.forEach(function(p){var s=0,t=p.t.toLowerCase(),b=(p.d+" "+p.k).toLowerCase(),ok=true;
    words.forEach(function(w){var a=t.indexOf(w)>-1?6:0,c=b.indexOf(w)>-1?2:0;if(!a&&!c)ok=false;s+=a+c});
    if(ok)out.push({p:p,s:s})}),out=out.sort(function(a,b){return b.s-a.s}).slice(0,12).map(function(x){return x.p});
  sel=-1;
  list.innerHTML=out.length?out.map(function(p){return '<li><a href="'+p.u+'"><span>'+esc(p.c)+'</span><b>'+hl(p.t,q)+'</b><small>'+hl(p.d,q)+'</small></a></li>'}).join(""):'<li class="sr-empty">No pages match “'+esc(q)+'”. Try “bonding”, “X-ray”, “interferometer” or “careers”.</li>';
}
function openSearch(){if(!ov)return;ov.hidden=false;d.body.style.overflow="hidden";sin.value="";search("");setTimeout(function(){sin.focus()},10)}
function closeSearch(){if(ov&&!ov.hidden){ov.hidden=true;d.body.style.overflow=""}}
$$("[data-search]").forEach(function(b){b.addEventListener("click",openSearch)});
if(ov){ov.addEventListener("click",function(e){if(e.target===ov)closeSearch()});
  sin.addEventListener("input",function(){search(sin.value)});
  sin.addEventListener("keydown",function(e){var a=$$("a",list);if(!a.length)return;
    if(e.key==="ArrowDown"||e.key==="ArrowUp"){e.preventDefault();sel=(sel+(e.key==="ArrowDown"?1:-1)+a.length)%a.length;a.forEach(function(x,i){x.classList.toggle("on",i===sel)});a[sel].scrollIntoView({block:"nearest"})}
    if(e.key==="Enter"){e.preventDefault();location.href=(a[sel<0?0:sel]).getAttribute("href")}})}
d.addEventListener("keydown",function(e){var tag=(e.target.tagName||"").toLowerCase();if(((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==="k")||(e.key==="/"&&!/input|textarea|select/.test(tag))){e.preventDefault();openSearch()}});

/* helper */
var helper=$(".helper-panel"), hbtn=$(".helper-btn");
function closeHelper(){if(helper&&!helper.hidden){helper.hidden=true;hbtn.setAttribute("aria-expanded","false")}}
if(hbtn)hbtn.addEventListener("click",function(){helper.hidden=!helper.hidden;hbtn.setAttribute("aria-expanded",String(!helper.hidden))});
$$(".to-top").forEach(function(b){b.addEventListener("click",function(){scrollTo({top:0,behavior:"smooth"})})});

/* TOC scrollspy */
var toc=$$(".toc a[href^='#']");
if(toc.length&&"IntersectionObserver" in window){
  var map={};toc.forEach(function(a){map[a.getAttribute("href").slice(1)]=a});
  var io=new IntersectionObserver(function(es){es.forEach(function(en){if(en.isIntersecting){toc.forEach(function(a){a.classList.remove("on")});var a=map[en.target.id];if(a)a.classList.add("on")}})},{rootMargin:"-30% 0px -60% 0px"});
  Object.keys(map).forEach(function(id){var s=d.getElementById(id);if(s)io.observe(s)});
}

/* finder */
var fdata=window.DYMEK_FINDER;
if(fdata&&$("#finder")){
  var chips=$$("#finder .chip"), panel=$("#finder-panel");
  function show(i){var it=fdata[i];chips.forEach(function(c,j){c.setAttribute("aria-selected",String(i===j));c.tabIndex=i===j?0:-1});
    $("#fp-title",panel).textContent=it.t; $("#fp-desc",panel).textContent=it.d; $("#fp-icon",panel).innerHTML=it.i;
    $("#fp-list",panel).innerHTML=it.l.map(function(x){return "<li>"+esc(x)+"</li>"}).join("");
    var a=$("#fp-link",panel); a.href=it.u; a.firstChild.nodeValue="Explore "+it.s+" ";
    var subs=$("#fp-subs",panel); subs.innerHTML=(it.sub||[]).map(function(s){return '<a class="chip" href="'+s[1]+'">'+esc(s[0])+'</a>'}).join(""); subs.hidden=!(it.sub&&it.sub.length);
  }
  chips.forEach(function(c,i){c.addEventListener("click",function(){show(i)});
    c.addEventListener("keydown",function(e){if(e.key==="ArrowRight"||e.key==="ArrowLeft"){e.preventDefault();var n=(i+(e.key==="ArrowRight"?1:-1)+chips.length)%chips.length;chips[n].focus();show(n)}})});
  show(0);
}

/* map: markers <-> office cards */
$$(".dmap-block").forEach(function(block){
  var ms=$$(".d-marker",block), cards=$$(".office",block);
  function act(id,scroll){ms.forEach(function(m){m.classList.toggle("on",m.dataset.id===id)});cards.forEach(function(c){var on=c.dataset.id===id;c.classList.toggle("on",on);if(on&&scroll)c.scrollIntoView({block:"nearest",behavior:"smooth"})})}
  ms.forEach(function(m){m.addEventListener("click",function(){act(m.dataset.id,true)});m.addEventListener("mouseenter",function(){act(m.dataset.id,false)})});
  cards.forEach(function(c){c.addEventListener("mouseenter",function(){act(c.dataset.id,false)});c.addEventListener("focus",function(){act(c.dataset.id,false)});c.addEventListener("click",function(){act(c.dataset.id,false)})});
});

/* video facade */
$$("a.video[data-yt]").forEach(function(a){a.addEventListener("click",function(e){
  if(!CAN_EMBED)return; // opens YouTube in a new tab
  e.preventDefault(); var id=a.dataset.yt, f=d.createElement("iframe");
  f.src="https://www.youtube-nocookie.com/embed/"+id+"?autoplay=1&rel=0"; f.title=a.getAttribute("aria-label")||"Video";
  f.allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"; f.allowFullscreen=true;
  a.replaceWith((function(){var w=d.createElement("div");w.className="video";w.appendChild(f);return w})());
})});

/* blog filter */
var bl=$("#blog-list");
if(bl){var cs=$$(".blog-cats .chip"), q=$("#blog-q"), cat="All";
  function filt(){var s=(q.value||"").toLowerCase(),n=0;$$("[data-cat]",bl).forEach(function(c){var ok=(cat==="All"||c.dataset.cat===cat)&&(!s||c.textContent.toLowerCase().indexOf(s)>-1);c.hidden=!ok;if(ok)n++});$("#blog-empty").hidden=n>0}
  cs.forEach(function(c){c.addEventListener("click",function(){cat=c.dataset.c;cs.forEach(function(x){x.setAttribute("aria-pressed",String(x===c))});filt()})});
  q.addEventListener("input",filt);
}

/* forms */
$$("form[data-form]").forEach(function(f){
  var status=$(".form-status",f.parentElement)||$(".form-status",f);
  f.addEventListener("submit",function(e){
    e.preventDefault(); var bad=null;
    $$("[required]",f).forEach(function(inp){var fl=inp.closest(".field"),ok=inp.checkValidity();if(fl)fl.classList.toggle("invalid",!ok);if(!ok&&!bad)bad=inp});
    if(bad){bad.focus();return}
    var btn=$("button[type=submit]",f); btn.disabled=true; var label=btn.innerHTML; btn.textContent="Sending…";
    function msg(cls,html){status.className="form-status notice "+cls;status.innerHTML=html;status.hidden=false;status.scrollIntoView({block:"nearest",behavior:"smooth"})}
    if(!LIVE){
      btn.disabled=false; btn.innerHTML=label;
      msg("info","<b>This preview isn’t connected to an inbox.</b><span>On the live site this form goes straight to our team. For now, please email <strong>"+f.dataset.to+"</strong> with your message.</span>");
      return;
    }
    var fd=new FormData(f), body = f.enctype==="multipart/form-data"?fd:new URLSearchParams(fd).toString();
    fetch("/",{method:"POST",headers:f.enctype==="multipart/form-data"?{}:{"Content-Type":"application/x-www-form-urlencoded"},body:body})
      .then(function(r){if(!r.ok)throw 0;f.reset();msg("ok","<b>Thank you. Your message has reached our team.</b><span>"+(f.dataset.ok||"We will review your inquiry and respond as soon as possible.")+"</span>")})
      .catch(function(){msg("bad","<b>We couldn’t send your message.</b><span>Please check your connection and try again, or email <strong>"+f.dataset.to+"</strong>.</span>")})
      .then(function(){btn.disabled=false;btn.innerHTML=label});
  });
  $$("input,textarea,select",f).forEach(function(i){i.addEventListener("input",function(){var fl=i.closest(".field");if(fl&&fl.classList.contains("invalid")&&i.checkValidity())fl.classList.remove("invalid")})});
});

/* share */
$$("[data-share]").forEach(function(a){var u=encodeURIComponent(a.dataset.url||location.href),t=encodeURIComponent(d.title);
  a.href=a.dataset.share==="linkedin"?"https://www.linkedin.com/sharing/share-offsite/?url="+u:a.dataset.share==="x"?"https://twitter.com/intent/tweet?url="+u+"&text="+t:a.href});

/* hero interferometer: live fringe simulation that follows the pointer (tilt) */
var cv=$("#fringes");
if(cv&&cv.getContext){
  var ctx=cv.getContext("2d"), W=0,H=0, tx=.18, ty=-.12, ttx=tx, tty=ty, t0=performance.now(), raf, reduce=matchMedia("(prefers-reduced-motion: reduce)").matches;
  function css(n){return getComputedStyle(root).getPropertyValue(n).trim()}
  function hex(c){c=c.replace("#","");if(c.length===3)c=c.split("").map(function(x){return x+x}).join("");var n=parseInt(c,16);return[n>>16&255,n>>8&255,n&255]}
  function size(){var r=cv.getBoundingClientRect(),s=Math.max(1,Math.min(2,devicePixelRatio||1));W=cv.width=Math.round(r.width*s/2);H=cv.height=Math.round(r.height*s/2)}
  var img;
  function draw(now){
    tx+=(ttx-tx)*.06; ty+=(tty-ty)*.06;
    var a=hex(css("--page")||"#ffffff"), b=hex(css("--primary")||"#7BB54E"), c=hex(css("--deep")||"#385E15");
    if(!img||img.width!==W)img=ctx.createImageData(W,H);
    var data=img.data, ph=(now-t0)/1400, cx=W/2, cy=H/2, R=W/2;
    for(var y=0;y<H;y++){for(var x=0;x<W;x++){var i=(y*W+x)*4,dx=(x-cx)/R,dy=(y-cy)/R,r2=dx*dx+dy*dy;
      if(r2>1){data[i+3]=0;continue}
      // surface: slight power + astigmatism + tilt (waves)
      var opd=3.2*r2+0.9*(dx*dx-dy*dy)+9*(tx*dx+ty*dy)+0.35*Math.sin(3*Math.atan2(dy,dx))*r2*r2;
      var v=.5+.5*Math.cos(2*Math.PI*opd+ph), m=v*v;
      data[i]=a[0]+(c[0]-a[0])*m*.92+(b[0]-a[0])*(1-m)*.12; data[i+1]=a[1]+(c[1]-a[1])*m*.92+(b[1]-a[1])*(1-m)*.12; data[i+2]=a[2]+(c[2]-a[2])*m*.92+(b[2]-a[2])*(1-m)*.12; data[i+3]=255}}
    ctx.putImageData(img,0,0);
    var rd=$("#ro-tilt"); if(rd) rd.textContent=(Math.hypot(tx,ty)*9).toFixed(2)+" λ";
    if(!reduce) raf=requestAnimationFrame(draw);
  }
  size(); addEventListener("resize",function(){size();cancelAnimationFrame(raf);raf=requestAnimationFrame(draw)});
  var sc=cv.parentElement;
  sc.addEventListener("pointermove",function(e){var r=cv.getBoundingClientRect();ttx=((e.clientX-r.left)/r.width-.5)*.5;tty=((e.clientY-r.top)/r.height-.5)*.5});
  sc.addEventListener("pointerleave",function(){ttx=.18;tty=-.12});
  if("IntersectionObserver" in window){new IntersectionObserver(function(es){es.forEach(function(en){cancelAnimationFrame(raf);if(en.isIntersecting&&!reduce)raf=requestAnimationFrame(draw)})}).observe(cv)}
  requestAnimationFrame(draw);
}

$$("[data-year]").forEach(function(s){s.textContent=new Date().getFullYear()});
})();
